To run first run `chmod u+x cron_lister.py` and ensure python 3 is used

