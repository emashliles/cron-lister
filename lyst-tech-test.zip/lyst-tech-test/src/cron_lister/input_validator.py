import sys


def validate_config(raw_config):
    cron_configs = []
    try:
        if sys.stdin.isatty():
            raise Exception
        for line in raw_config:
            stripped = line.strip()
            cron_configs.append(stripped)
    except:
        print('No config provided')

    return cron_configs