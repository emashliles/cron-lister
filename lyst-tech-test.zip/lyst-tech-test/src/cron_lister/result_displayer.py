from src.cron_lister.time_calculator import calculate_next_time, calculate_day


def print_error_message():
    print('Currently no upcoming cron jobs to display')


def display_results(config, start_time):
    if not config:
        print_error_message()
        return

    for item in config:
        next_time = calculate_next_time(start_time,item)
        script_name = item.split()[2]
        print(f'{format_time(next_time)} {calculate_day(start_time, next_time)} - {script_name}')


def format_time(next_time):
    formatted_time = next_time.isoformat(timespec='minutes')
    return f'{formatted_time}'