import datetime


def calculate_next_time(given_time, config):
    config_parts = config.split()
    raw_minute = config_parts[0]
    raw_hour = config_parts[1]

    if raw_minute is '*' and raw_hour is '*':
        return given_time

    if raw_minute is '*' and raw_hour is not '*':
        return datetime.time(int(raw_hour), 0)

    if raw_minute is not '*' and raw_hour is '*':
        if int(raw_minute) < given_time.minute:
            if given_time.hour is 23:
                return datetime.time(0, int(raw_minute))
            return datetime.time(given_time.hour + 1, int(raw_minute))
        else:
            return datetime.time(given_time.hour, int(raw_minute))

    specified_time = datetime.time(int(raw_hour), int(raw_minute))

    return specified_time


def calculate_day(given_time, next_time):
    if next_time is given_time:
        return 'today'

    if given_time > next_time:
        return 'tomorrow'
    else:
        return 'today'
