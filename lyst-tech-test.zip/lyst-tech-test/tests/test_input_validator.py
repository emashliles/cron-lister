import io
from contextlib import redirect_stdout

from src.cron_lister.input_validator import validate_config


def test_error_is_returned_when_no_test_file_given():
    f = io.StringIO()
    with redirect_stdout(f):
        validate_config(None)
    out = f.getvalue()
    assert out == 'No config provided\n'

def test_list_of_cron_configs_are_returned_if_present():
    expected_cron_configs = ['30 1 /bin/run_me_daily', '45 * /bin/run_me_hourly']
    mock_config_input = io.StringIO(f'{expected_cron_configs[0]}\n{expected_cron_configs[1]}')
    cron_configs = validate_config(mock_config_input)
    assert cron_configs == expected_cron_configs
