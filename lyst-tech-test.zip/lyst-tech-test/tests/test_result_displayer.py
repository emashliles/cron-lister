import datetime
import io
from contextlib import redirect_stdout

from src.cron_lister.result_displayer import display_results


def test_jobs_are_displayed_in_correct_format():
    given_cron_configs = ['30 1 /bin/run_me_daily']
    f = io.StringIO()
    with redirect_stdout(f):
        display_results(given_cron_configs, datetime.time(12, 0))
    out = f.getvalue()
    assert out == '01:30 tomorrow - /bin/run_me_daily\n'