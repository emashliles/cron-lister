import datetime

from src.cron_lister.time_calculator import calculate_next_time, calculate_day


def test_minute_past_the_hour_if_it_equals_given_time():
    result = calculate_next_time(datetime.time(12, 30), '30 * /bin/run_me_daily')
    assert result == datetime.time(12, 30)


def test_minute_past_the_hour_is_calculated_if_minute_past_hour_is_in_future():
    result = calculate_next_time(datetime.time(12, 00), '40 * /bin/run_me_daily')
    assert result == datetime.time(12, 40)


def test_minute_past_the_hour_is_calculated_if_minute_past_hour_is_in_past():
    result = calculate_next_time(datetime.time(12, 30), '10 * /bin/run_me_daily')
    assert result == datetime.time(13, 10)


def test_minute_past_hour_is_calculated_for_star():
    result = calculate_next_time(datetime.time(12, 30), '* * /bin/run_me_daily')
    assert result == datetime.time(12,30)


def test_minute_past_hour_is_calculated_for_specified_minutes_hour_star():
    result = calculate_next_time(datetime.time(12, 30), '40 * /bin/run_me_daily')
    assert result == datetime.time(12,40)


def test_minute_past_hour_is_calculated_for_star_minutes_specified_hour():
    result = calculate_next_time(datetime.time(12, 30), '* 13 /bin/run_me_daily')
    assert result == datetime.time(13, 0)


def test_minute_past_hour_is_calculated_for_specified_minutes_and_specified_hour():
    result = calculate_next_time(datetime.time(12, 30), '40 13 /bin/run_me_daily')
    assert result == datetime.time(13, 40)


def test_can_wrap_around_midnight():
    result = calculate_next_time(datetime.time(23, 30), '1 * /bin/run_me_daily')
    assert result == datetime.time(0, 1)


def test_today_is_calculated_correctly_for_star():
    result = calculate_day(datetime.time(12, 30), datetime.time(12, 30))
    assert result == 'today'


def test_today_is_calculated_correctly_for_given_time():
    result = calculate_day(datetime.time(12, 30), datetime.time(12, 30))
    assert result == 'today'


def test_today_is_calculated_correctly_for_minutes_past_hour():
    result = calculate_day(datetime.time(12, 00), datetime.time(12, 30))
    assert result == 'today'


def test_tomorrow_is_calculated_correctly_for_minutes_past_hour():
    result = calculate_day(datetime.time(23, 31), datetime.time(0, 30))
    assert result == 'tomorrow'
