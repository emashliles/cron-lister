#!/usr/bin/python
import sys
import datetime

from src.cron_lister.input_validator import validate_config
from src.cron_lister.result_displayer import display_results

time_parameter = sys.argv[1]
time_format = '%H:%M'

config = validate_config(sys.stdin)
start_time = datetime.datetime.strptime(time_parameter, time_format).time()
display_results(config, start_time)
